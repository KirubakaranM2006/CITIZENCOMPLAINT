package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CitizenComplaintSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CitizenComplaintSystemApplication.class, args);
	}

}
